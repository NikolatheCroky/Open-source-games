package com.game.main;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.game.main.Game.STATE;

public class KeyInput extends KeyAdapter{
	
	
	
	private Handler handler;
	//private boolean[] keysDown = new boolean[4];
	
	public KeyInput(Handler handler) {
		this.handler = handler;
		
		//keysDown[0] = false;
		//keysDown[1] = false;
		//keysDown[2] = false;
		//keysDown[3] = false;
	}
	
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		
		for(int i = 0; i <handler.object.size(); i++) {
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ID.Player && Game.gamestate == STATE.Game) {
				
				if(key == KeyEvent.VK_UP) { tempObject.setVely(-5); }
				if(key == KeyEvent.VK_DOWN) { tempObject.setVely(5); }
				if(key == KeyEvent.VK_RIGHT) { tempObject.setVelx(5); }
				if(key == KeyEvent.VK_LEFT) { tempObject.setVelx(-5); }
				
				
				
				
			}
		}
		
		if(key == KeyEvent.VK_ESCAPE) {
			if(Game.gamestate == STATE.Game) {
				for(int i1 = 0; i1 < handler.object.size(); i1++) {
					GameObject tempObject1 = handler.object.get(i1);
					
					if(tempObject1.getId() == ID.BasicEnemy) {
						tempObject1.velx = 0;
						tempObject1.vely = 0;
					}
				}
				Game.gamestate = STATE.Pause;
			}else if(Game.gamestate == STATE.Pause) {
				Game.gamestate = STATE.Menu;
			}else System.exit(1);
			
		}else if(key == KeyEvent.VK_ENTER) {
			if(Game.gamestate == STATE.Pause) {
				for(int i1 = 0; i1 < handler.object.size(); i1++) {
					GameObject tempObject1 = handler.object.get(i1);
					
					if(tempObject1.getId() == ID.BasicEnemy) {
						tempObject1.velx = tempObject1.dvelx;
						tempObject1.vely = tempObject1.dvely;
					}
				}
				Game.gamestate = STATE.Game;
			}
		}
		
		
	}
	
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		
		for(int i = 0; i <handler.object.size(); i++) {
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ID.Player) {
				
				if(key == KeyEvent.VK_UP)      tempObject.setVely(0);
				if(key == KeyEvent.VK_DOWN)    tempObject.setVely(0);
				if(key == KeyEvent.VK_RIGHT)   tempObject.setVelx(0);
				if(key == KeyEvent.VK_LEFT)    tempObject.setVelx(0);
				
				//if(!keysDown[0] && !keysDown[1]) tempObject.setVely(0);
				//else if(!keysDown[2] && !keysDown[3]) tempObject.setVelx(0);
				//else if(!keysDown[0] && !keysDown[1] && !keysDown[2] && !keysDown[3]) tempObject.setVelx(0); tempObject.setVely(0);
				
			}
		}
	}
}
