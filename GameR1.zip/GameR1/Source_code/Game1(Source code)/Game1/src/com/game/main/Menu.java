package com.game.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import com.game.main.Game.STATE;

public class Menu extends MouseAdapter{
	
	Game game;
	Handler handler;
	HUD hud = new HUD();
	Random r0 = new Random();
	public boolean help = false;
	private Spawn spr;
	
	
	public Menu(Game game, Handler handler, Spawn spr) {
		this.game = game;
		this.handler = handler;
		this.spr = spr;
	}
	
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
		
		if(Game.gamestate == STATE.Menu) {
			
			if(mouseOver(mx, my, Game.WIDTH / 2 - 170, 100, 300, 100 )) {
				//Play code
				game.gamestate = STATE.Game;
				handler.addObject(new Player(Game.WIDTH / 2 - 32, Game.HEIGHT / 2 - 32, ID.Player, handler));
				
				handler.addObject(new BasicEnemy(r0.nextInt(Game.WIDTH), r0.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));
				handler.addObject(new FastEnemy(r0.nextInt(Game.WIDTH), r0.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));
			}
			
			if(mouseOver(mx, my, Game.WIDTH / 2 - 170, 250, 300, 100 )) {
				//Coming soon button code
				
			}
			
			if(mouseOver(mx, my, Game.WIDTH / 2 - 170, 400, 300, 100)) {
				//Quit code
				System.exit(1);
			}
		}
		
	}
	
	public void mouseReleased(MouseEvent e) {
		
	}
	
	private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
		boolean this1 = false;
		if(mx > x && mx < x + width) {
			if(my > y && my < y + height) {
				this1 = true;
			}
		}
		else this1 = false;
		
		return this1;
	}
	
	public void tick() {
		
	}
	
	public void render(Graphics g) {
		
			
				
			
			
			Font fnt1 = new Font("arial", 1, 70);
			g.setFont(fnt1);
					
					
			g.setColor(Color.white);
			g.drawString("Menu", Game.WIDTH / 2 - 110, 60);
			g.drawRect(Game.WIDTH / 2 - 170, 100, 300, 100);
			g.drawRect(Game.WIDTH / 2 - 170, 250, 300, 100);
			g.drawRect(Game.WIDTH / 2 - 170, 400, 300, 100);
			g.drawString("Play",Game.WIDTH / 2 - 100, 170);
			Font fnt2 = new Font("arial", 1, 30);
			g.setFont(fnt2);
			g.drawString("Button coming soon",Game.WIDTH / 2 - 160, 315);
			g.setFont(fnt1);
			g.drawString("Quit", Game.WIDTH / 2 - 100, 470);
			
	}
	
}
