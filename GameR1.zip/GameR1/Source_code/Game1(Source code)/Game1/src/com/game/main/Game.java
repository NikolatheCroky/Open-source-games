package com.game.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.Random;

import com.game.main.Game.STATE;

public class Game extends Canvas implements Runnable{
	
	private static final long serialVersionUID = -473349850293143017L;
	
	public static final int WIDTH = 900, HEIGHT = WIDTH / 12 * 9;
	private Thread thread;
	private boolean running = false;
	
	private Handler handler;
	private Random r0;
	public static int frames1;
	private HUD hud;
	private Spawn spr;
	private Menu menu;
	
	
	public enum STATE {
		Menu,
		Game,
		Pause,
		Help;
		
		
	};
	public static STATE gamestate = STATE.Menu;
	
	public Game() {
		handler = new Handler();
		this.addKeyListener(new KeyInput(handler));
		hud = new HUD();
		spr = new Spawn(handler, hud);
		menu = new Menu(this, handler, spr);
		this.addMouseListener(menu);
		new Window(WIDTH, HEIGHT, "Game", this);
		
		r0 = new Random();
		
		if(gamestate == STATE.Game) {
			handler.addObject(new Player(WIDTH / 2 - 32, HEIGHT / 2 - 32, ID.Player, handler));
			
			handler.addObject(new BasicEnemy(r0.nextInt(Game.WIDTH), r0.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));
			handler.addObject(new FastEnemy(r0.nextInt(Game.WIDTH), r0.nextInt(Game.HEIGHT), ID.FastEnemy, handler));
		}
		
	}
	
	
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop() {
		try {
			thread.join();
		}catch(Exception e){
			e.printStackTrace();
		}
		running = false;
	}
	
	public void run() {
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta >= 1) {
				tick();
				delta--;
			}
			if(running) {
				render();
				frames++;
			}
				
			
			if(System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println("FPS: " + frames);
				frames1 = frames;
				frames = 0;
			}
		}
		stop();
	}
	
	public static float clamp(float var, int min, int max) {
		if(var >= max) var = max;
		if(var <= min) var = min;
		return var;
	}
	
	public void tick() {
		handler.tick();
		hud.tick();
		if(gamestate == STATE.Game || gamestate == STATE.Pause) {
			spr.tick();
			
			if(hud.HEALTH == 0) {
				Game.gamestate = STATE.Menu;
				handler.object.clear();
			}
			
		}else if(gamestate == STATE.Menu) menu.tick();
		else if(gamestate == STATE.Pause) {
			for(int i1 = 0; i1 < handler.object.size(); i1++) {
				GameObject tempObject1 = handler.object.get(i1);
				
				if(tempObject1.getId() == ID.BasicEnemy) {
					tempObject1.velx = 0;
					tempObject1.vely = 0;
				}
			}
		}
		
	}
	
	
	
	public void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		
		handler.render(g);
		hud.render(g);
		
		if(gamestate == STATE.Menu) menu.render(g);
		Font fnt1 = new Font("arial", 1, 20);
		g.setFont(fnt1);
		g.setColor(Color.green);
		g.drawString("FPS: " + frames1, WIDTH - 100, 23);
		g.dispose();
		bs.show();
	}
	
	public static void main(String args[]) {
		new Game();
	}
	
	
	
}
