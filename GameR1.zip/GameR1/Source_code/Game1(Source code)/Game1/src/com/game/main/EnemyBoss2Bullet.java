package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

import com.game.main.Game.STATE;

public class EnemyBoss2Bullet extends GameObject {
	
	private Handler handler;
	Random r0 = new Random();
	int timer = 0;
	private GameObject player;

	
	public EnemyBoss2Bullet(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;
		
		for(int i = 0; i < handler.object.size(); i++) {
			if(handler.object.get(i).getId() == ID.Player) {
				player = handler.object.get(i);
			}
		}
		
		if(Game.gamestate == STATE.Game) {
			velx = r0.nextInt((5 - -5) + -5);
			vely = 2;
		}
	}


	public void tick() {
		if(Game.gamestate == STATE.Game) {
			x += velx;
			y += vely;
			
			if(Game.gamestate == STATE.Game) {
				if(velx == 0 && vely == 0) {
					velx = r0.nextInt((5 - -5) + -5);
					vely = 2;
				}
			}			
			
			//float f00 = (player.getX() * -1);
			//float f0 = (player.getX() - x) * -f00;
			//float diffx = x - player.getX() - (player.getX() * f0);
			//float diffy = y - player.getY() - 32;
			//float distance = (float) Math.sqrt( (x - player.getX() ) * (x - player.getX()) + (y - player.getY()) * (y - player.getY()) );
			//float distance = (float) Math.sqrt( (diffx * diffx) + (diffy * diffy));
			
			//velx = (float) ((-1.0/distance) * diffx);
			velx = Game.clamp(velx, -5, 5);
			//vely = (float) ((-5.0/distance) * diffy);
			vely = Game.clamp(vely, -5, 5);
			//if(y >= Game.HEIGHT - 50) handler.removeObject(this);
			//if(y <= 0 +50) handler.removeObject(this);
			//if(x >= Game.WIDTH - 50) handler.removeObject(this);
			//if(x <= 0 +50) handler.removeObject(this);
			
			
			//handler.addObject(new Trail(x, y,ID.Trail, Color.red, 16, 16, 0.04f , handler));
		}else if(Game.gamestate == STATE.Pause) {
			velx = 0;
			vely = 0;
		}
		
	}
	

	
	public void render(Graphics g) {
		
		g.setColor(Color.red);
		g.fillRect((int)x, (int)y, 10, 15);
	}


	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x, (int)y, 10, 15);
	}

}
