package com.game.main;

public enum ID {
	
	Player(),
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	Enemy(),
	Coin(),
	Trail();
	
	
	
	
	
}
