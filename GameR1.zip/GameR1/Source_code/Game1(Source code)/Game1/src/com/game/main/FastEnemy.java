package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class FastEnemy extends GameObject{
private Handler handler;

	
	public FastEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;
		
		velx = 1;
		vely = 10;
		dvelx = 1;
		dvely = 10;
		
	}


	public void tick() {
		x += velx;
		y += vely;
		
		y = Game.clamp(y, 0, Game.HEIGHT - 64);
		x = Game.clamp(x, 0, Game.WIDTH - 64);
		if(y <= 0 || y >= Game.HEIGHT - 64) vely *= -1;
		if(x <= 0 || x >= Game.WIDTH - 64) velx *= -1;
		
		handler.addObject(new Trail(x, y,ID.Trail, Color.yellow, 32, 32, 0.04f , handler));
	}
	

	
	public void render(Graphics g) {
		
		g.setColor(Color.yellow);
		g.fillRect((int)x, (int)y, 32, 32);
	}


	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x, (int)y, 32, 32);
	}
}
