package com.game.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import com.game.main.Game.STATE;

public class HUD {
	
	
	
	public static int HEALTH = 100;
	public int health = HEALTH;
	private int green = 255;
	private Handler handler = new Handler();
	private Spawn spawn = new Spawn(handler, this);
	
	
	
	public int score = 0;
	public int totalscore = 0;
	public int lvl = 1;
	
	
	public void tick() {
		
		HEALTH = (int) Game.clamp(HEALTH, 0, 100);
		green = (int) Game.clamp(green, 0, 255);
		green = HEALTH * 2;
		
		if(Game.gamestate == STATE.Game) {
			score++;
			totalscore++;
		}else if(Game.gamestate == STATE.Menu) {
			score = 0;
			lvl = 1;
			HEALTH = 100;
		}
		
	}
	
	public void render(Graphics g) {
		int i0 = 64;
		if(Game.gamestate == STATE.Game || Game.gamestate == STATE.Pause){
			g.setColor(Color.white);
			g.fillRect(15, 15, 207, 33);
			g.setColor(new Color(75, green, 0));
			g.fillRect(18, 18, HEALTH * 2, 27);
			
			g.setColor(Color.white);
			
			g.drawString("Total score: " + totalscore, 10, i0);
			g.drawString("Score: " + score, 10, i0 + 16 );
			g.drawString("Level: " + lvl, 10, i0 + 32);			
			//g.drawString("Enemies: " + spawn.enemy, 10, i0 + 32);
		}
		
		
	}
	
	public void score(int score) {
		this.score = score;
	}

	public int getLvl() {
		return lvl;
	}
	
	public int getScore() {
		return score;
	}

	public void setLvl(int lvl) {
		this.lvl = lvl;
	}

	
}
