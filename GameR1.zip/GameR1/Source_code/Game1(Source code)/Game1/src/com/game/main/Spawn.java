package com.game.main;

import java.util.Random;

import com.game.main.Game.STATE;

public class Spawn {
	
	private Handler handler;
	private HUD hud;
	//public int slvlup = 1000;
	public int enemy = 1;
	Random r = new Random();
	
	private int scoreKeep = 0;
	private int EnemyNum = 0;
	public int i0000 = 0;
	public static int i1 = 0;
	
	public Spawn(Handler handler, HUD hud) {
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick() {
		if(Game.gamestate == STATE.Game) {
			scoreKeep++;
		}else if(Game.gamestate == STATE.Menu) {
			scoreKeep = 0;
		}
		
		
		if(scoreKeep >= 1000) {
			scoreKeep = 0;
			hud.setLvl(hud.getLvl() + 1);
			//slvlup = slvlup * 2;
			
			//if(hud.getLvl() == 2) {
			//int i = 0;
			//i = (int) Game.clamp(i, hud.lvl, hud.lvl);
			
			if(hud.lvl == 3) {
				handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH -50), r.nextInt(Game.HEIGHT - 50), ID.SmartEnemy, handler));
			}
			if(hud.lvl == 10) {
				handler.clearEnemies();
				handler.addObject(new BossEnemy2(Game.WIDTH / 2 - 48, 48, ID.BasicEnemy, handler, this));
				i1 = 200;
			}
			if(hud.lvl == 12) {
				handler.object.clear();
				Game.gamestate = STATE.Menu;
			}
			//if(i == hud.lvl) {
				//for(int i0 = 0; i0 < i; i0++) {
					//handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH -50), r.nextInt(Game.HEIGHT - 50), ID.BasicEnemy, handler));
				//}
		//	}
			
		//	}
		//	enemy += i;
		//	if(enemy < 50);
		}
		
		
	}
	
	
	
}
