package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Player extends GameObject {
	
	private Handler handler;
	private int dammagecooldown = 10;

	public Player(int x, int y, ID id, Handler handler){
		super(x, y, id);
		this.handler = handler;
	}

	
	public void tick() {
		x += velx;
		y += vely;
		
		y = Game.clamp((int) y, 0 + Spawn.i1, Game.HEIGHT - 60 );
		x = Game.clamp((int) x, 0, Game.WIDTH - 37 );
		
		colide();
	}

	public void colide() {
		for(int i = 0; i < handler.object.size(); i++) {
			
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getId() == ID.BasicEnemy || tempObject.getId() == ID.FastEnemy || tempObject.getId() == ID.SmartEnemy) {
				if(getBounds().intersects(tempObject.getBounds())) {
					//collision code
					if(dammagecooldown == 10) {
						HUD.HEALTH -= 1;
						dammagecooldown = 0;
					}else dammagecooldown++;
					
					
				}
			}
			
		}
	}
	
	public void render(Graphics g) {
		
		Graphics2D g2d = (Graphics2D) g;
		
		g.setColor(Color.white);
		g.fillRect((int)x, (int)y, 32, 32);
		g.setColor(Color.red);
		g2d.draw(getBounds());
	}


	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x, (int)y, 32 ,32);
	}

}
	