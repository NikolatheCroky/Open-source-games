package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

import com.game.main.Game.STATE;

public class BossEnemy2 extends GameObject {
	
	private Handler handler;
	private GameObject player;
	public int timer = 50;
	public int timer2 = 50;
	Random r0 = new Random();
	private int spawnz = 0;
	private Spawn spr;

	
	public BossEnemy2(int x, int y, ID id, Handler handler, Spawn spr) {
		super(x, y, id);
		
		
		this.handler = handler;
		this.spr = spr;
		
		if(Game.gamestate == STATE.Game) {
			for(int i = 0; i < handler.object.size(); i++) {
				if(handler.object.get(i).getId() == ID.Player) {
					player = handler.object.get(i);
				}
			}
			
			vely = 1;
		}
		}
		


	public void tick() {
		if(Game.gamestate == STATE.Game) {
			x += velx;
			y += vely;
			
			if(timer <= 0) {
				vely = 0;
			}else timer--;
			
			if(timer <=0) {
				timer2--;
			}
			if(timer2 <= 0) {
				if(velx == 0) velx = 2;
				spawnz++;
				if(spawnz == 10){handler.addObject(new EnemyBoss2Bullet((int)x, (int)y, ID.BasicEnemy, handler)); spawnz = 0;}
			}
			
			if(spr.i0000 == 1) handler.removeObject(this);
			
			
			
			y = Game.clamp( (int)y, 0, Game.HEIGHT - 192);
			x = Game.clamp( (int)x, 0, Game.WIDTH - 192);
			if(y <= 0 || y >= Game.HEIGHT - 192) vely *= -1;
			if(x <= 0 || x >= Game.WIDTH - 192) velx *= -1;
			
			
			handler.addObject(new Trail(x, y,ID.Trail, Color.DARK_GRAY, 96, 96, 0.04f , handler));
		}else if(Game.gamestate == STATE.Pause) {
			velx = 0;
			vely = 0;
		}
		
	}
	

	
	public void render(Graphics g) {
		
		g.setColor(Color.DARK_GRAY);
		g.fillRect((int)x, (int)y, 96, 96);
	}


	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x, (int)y, 96, 96);
	}

}

