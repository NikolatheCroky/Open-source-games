package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import com.game.main.Game.STATE;

public class SmartEnemy extends GameObject {
	
	private Handler handler;
	private GameObject player;
	
	
	

	
	public SmartEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;
		
		for(int i = 0; i < handler.object.size(); i++) {
			if(handler.object.get(i).getId() == ID.Player) {
				player = handler.object.get(i);
			}
		}
		
		
		
	}


	public void tick() {
		if(Game.gamestate == STATE.Game) {
			x += velx;
			y += vely;
			
			float f00 = (player.getX() * -1);
			float f0 = (player.getX() - x) * -f00;
			float diffx = x - player.getX() - (player.getX() * f0);
			float diffy = y - player.getY() - 32;
			//float distance = (float) Math.sqrt( (x - player.getX() ) * (x - player.getX()) + (y - player.getY()) * (y - player.getY()) );
			float distance = (float) Math.sqrt( (diffx * diffx) + (diffy * diffy));
			
			velx = (float) ((-1.0/distance) * diffx);
			velx = Game.clamp(velx, -5, 5);
			vely = (float) ((-5.0/distance) * diffy);
			vely = Game.clamp(vely, -5, 5);
			//this.x += player1.x;
			//this.y += player1.y;
			
			
			y = Game.clamp( (int)y, 0, Game.HEIGHT - 32);
			x = Game.clamp( (int)x, 0, Game.WIDTH - 32);
			if(y <= 0 || y >= Game.HEIGHT - 32) vely *= -f00;
			if(x <= 0 || x >= Game.WIDTH - 32) velx *= -f00;
			
			
			handler.addObject(new Trail(x, y,ID.Trail, Color.CYAN, 32, 32, 0.04f , handler));
		}else if(Game.gamestate == STATE.Pause) {
			velx = 0;
			vely = 0;
		}
		
		
		
		}

	
	public void render(Graphics g) {
		
		g.setColor(Color.CYAN);
		g.fillRect((int)x, (int)y, 32, 32);
	}


	
	public Rectangle getBounds() {
		
		return new Rectangle((int)x, (int)y, 32, 32);
	}

}
