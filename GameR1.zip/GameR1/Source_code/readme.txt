Source code was provided in an eclipse project format. It will not work with other IDEs unless you copy
 it using a text editing program or transform it in some other way.
