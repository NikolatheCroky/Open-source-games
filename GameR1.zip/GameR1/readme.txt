Use keyboard arrows to move while in game. Use your mouse to navigate in the menu. While int game press
Esc to pause. While paused press enter to resume the game and Esc to exit to menu. While in menu press Esc
to close the window. The reset button doesn't function, but it and more suff will be coming in the future.